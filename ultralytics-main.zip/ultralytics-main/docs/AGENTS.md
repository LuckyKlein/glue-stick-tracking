# AGENTS.md

Instructions for `docs/`; `CLAUDE.md` points here. Follow the root `AGENTS.md` for repository-wide rules, including the pinned prettier command for `docs/**/*.md`.

## Ownership

- Pages live in `docs/en/`; the root `mkdocs.yml` owns navigation and Markdown configuration. Relative `.md` cross-file links are the correct convention in `docs/en/` — production is rendered by the centralized publisher, and the local build intentionally omits production-owned site chrome.
- Shared tables live in `docs/macros/` (`augmentation-args.md`, `export-args.md`, `export-table.md`, `platform-*.md`, ...) and are included into pages such as `docs/en/usage/cfg.md`; edit the macro owner, never copy a table into a consuming page. Jinja default values come from `ultralytics/cfg/default.yaml`.
- `docs/en/reference/` is generated from Python docstrings — API prose belongs in the docstring, not in the reference page. `reference/index.md` is the one hand-written page there.
- Comparison pages are imported from the `ultralytics/docs` GitHub repository during the full build.
- `<canvas id="modelComparisonChart">` and `<platform-annotation-models></platform-annotation-models>` are components the production publisher renders (the benchmark chart, and Platform's paid annotation models from its model registry); keep them even though they render empty locally and on GitHub.

## Commands

Run from the repository root. Full validation needs Python 3.10+ and `uv pip install -e ".[dev]"` (installs `zensical` and `minijinja`), plus network access for the comparison-page clone.

```bash
# Regenerate docs/en/reference/ after adding/removing/renaming public APIs (docs.yml runs this and pushes the result)
python docs/build_reference.py

# Prepare the complete docs tree (macros, references, comparison pages) and validate it with `zensical build --strict`
python docs/build_docs.py

# Preview the completed build
python -m http.server --directory site
```

- `build_reference.py` (stub flow, `build_reference_placeholders`) rewrites the tracked placeholder stubs, deletes orphan stubs, preserves `reference/index.md`, and updates the reference navigation in `mkdocs.yml`.
- `build_docs.py` temporarily renders the full docstring-based references (`create_markdown`), comparison pages, and macros into `docs/en`, builds `site/`, then restores `docs/en` and `docs/macros` from a backup. The full render fails when a parameter type is missing from both the signature and the docstring, and `create_markdown()` runs `git add -f` on newly created reference files — the directory restore does not touch the Git index, so inspect `git diff --cached` as well as `git diff` before committing. `zensical serve` is fine for simple page previews but performs none of that preparation, so it cannot validate macros, references, or comparison pages.
