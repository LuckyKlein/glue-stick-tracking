---
plans: [free, pro, enterprise]
comments: true
description: Annotate images in Ultralytics Platform by hand or with AI auto-annotation from SAM 3.1, YOLO, and models like Gemini 4 Argon, GPT-6.1 Sol, and Claude Opus 5.5.
keywords: Ultralytics Platform, annotation, labeling, auto-annotation, AI labeling, SAM 3.1, YOLO, Gemini 4 Argon, GPT-6.1 Sol, GPT-6 Astra, Claude Opus 5.5, Claude Fable 5.1, Claude Sonnet 5.5, Gemini 3.8 Flash, vision language models, Moondream, Qwen, YOLOE, Grounding DINO, bounding box, polygon, keypoints, skeleton templates, pose estimation, segmentation
---

# Annotation Editor

[Ultralytics Platform](https://platform.ultralytics.com) includes an annotation editor for labeling images with bounding boxes, polygons, keypoints, oriented boxes, and classifications. The editor supports manual drawing, [SAM-powered smart annotation](https://www.ultralytics.com/annotate), and predictions from compatible YOLO models or, on detection datasets with 1–200 classes, class-prompted models: hosted open-source models or paid provider models.

![Ultralytics Platform Annotate Editor Toolbar With Canvas](https://cdn.ul.run/i/5ba36616a9363a036217c9b058daf35c.avif)<!-- screenshot -->

```mermaid
flowchart TD
    A([Open an image]) --> B{Annotation mode?}
    B -->|draw| C[Draw shapes]
    B -->|smart| D[SAM or model labels]
    C --> E([Labels save automatically])
    D --> E
```

## Supported Task Types

The annotation editor provides annotation tools for 6 YOLO task types:

| Task                                             | Tool           | Annotation Format                                         |
| ------------------------------------------------ | -------------- | --------------------------------------------------------- |
| **[Detect](../../datasets/detect/index.md)**     | Rectangle      | Bounding boxes (x, y, width, height)                      |
| **[Segment](../../datasets/segment/index.md)**   | Polygon        | Pixel-precise masks (polygon vertices)                    |
| **[Semantic](../../datasets/semantic/index.md)** | Polygon        | Per-class region masks (polygon vertices)                 |
| **[Classify](../../datasets/classify/index.md)** | Class Selector | Image-level labels                                        |
| **[Pose](../../datasets/pose/index.md)**         | Keypoint       | Skeleton templates (Person, Hand, Dog, Face, Box, custom) |
| **[OBB](../../datasets/obb/index.md)**           | Oriented Box   | Rotated bounding boxes (4 corners)                        |

!!! tip "Multi-Task Annotations"

    All 6 annotation types are stored together on each image. You can switch the dataset's active task type without losing existing annotations — they are preserved and reappear when you switch back.

[Depth ground truth](../../datasets/depth/index.md#depth-map-format) is a paired map you upload, not something you draw, so the editor opens read-only on a depth dataset.

### Task Details

??? info "Object Detection"

    **What it does:** Identifies objects and their locations with axis-aligned bounding boxes.

    **Label format:** [`class_id center_x center_y width height`](../../datasets/detect/index.md#ultralytics-yolo-format) (all normalized 0-1)

    **Example:** `0 0.5 0.5 0.2 0.3` — Class 0 centered at (50%, 50%) with 20% width and 30% height

    **Use cases:** Inventory counting, traffic monitoring, wildlife detection, security systems

??? info "Instance Segmentation"

    **What it does:** Creates pixel-precise masks for each object instance.

    **Label format:** [`class_id x1 y1 x2 y2 x3 y3 ...`](../../datasets/segment/index.md#ultralytics-yolo-format) (polygon vertices, normalized 0-1)

    **Example:** `0 0.1 0.1 0.9 0.1 0.9 0.9 0.1 0.9` — Quadrilateral mask

    **Use cases:** Medical imaging, autonomous vehicles, photo editing, agricultural analysis

??? info "Pose Estimation"

    **What it does:** Detects body keypoints for skeleton tracking.

    **Label format:** [`class_id cx cy w h kx1 ky1 v1 kx2 ky2 v2 ...`](../../datasets/pose/index.md#ultralytics-yolo-format)

    - Visibility flags: `0`=not labeled, `1`=labeled but occluded, `2`=labeled and visible

    **Example:** `0 0.5 0.5 0.2 0.3 0.6 0.7 2 0.4 0.8 1` — Person with 2 keypoints

    **Use cases:** Sports analysis, physical therapy, animation, gesture recognition

??? info "Oriented Bounding Box (OBB)"

    **What it does:** Detects rotated objects with angle-aware bounding boxes.

    **Label format:** [`class_id x1 y1 x2 y2 x3 y3 x4 y4`](../../datasets/obb/index.md#yolo-obb-format) (four corner points, normalized)

    **Example:** `0 0.1 0.1 0.9 0.1 0.9 0.9 0.1 0.9` — Rotated rectangle

    **Use cases:** Aerial imagery, document analysis, manufacturing inspection, ship detection

??? info "Image Classification"

    **What it does:** Assigns a single label to the entire image.

    **Label format:** [Folder-based](../../datasets/classify/index.md#dataset-structure-for-yolo-classification-tasks) — images organized by class name (`train/cats/`, `train/dogs/`)

    **Use cases:** Content moderation, quality control, medical diagnosis, scene recognition

## Getting Started

To annotate images:

1. Navigate to your dataset
2. Click an image once to open the fullscreen annotation editor
3. Use the default `Draw` mode, or switch to `Smart` where supported
4. Select a class and add or adjust annotations directly on the image
5. Continue to another image or close the editor; changes save automatically after each edit

For datasets you can edit, annotation controls are active as soon as the fullscreen viewer opens on desktop. There is no separate edit mode or `Edit` button. On mobile, and when you do not have edit access, the fullscreen viewer is read-only.

![Ultralytics Platform Fullscreen Annotation Editor With Toolbar](https://cdn.ul.run/i/3c42ebce6b9e551108eab728c3b93c13.avif)<!-- screenshot -->

```mermaid
flowchart TD
    A([Open a dataset]) --> B[Click an image]
    B --> C[Annotate in fullscreen]
    C --> D[Changes save automatically]
    D --> E{Next image?}
    E -->|yes| C
    E -->|no| F([Close the editor])
```

## Annotation Modes

`Draw` is the default mode for spatial annotation tasks. For detect, segment, semantic, pose, and OBB datasets, the toolbar also provides `Smart` mode when Smart annotation is available:

| Mode      | Description                                                                                                                                                                                                                                         | Shortcut |
| --------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------- |
| **Draw**  | Default manual mode with task-specific drawing tools                                                                                                                                                                                                | `V`      |
| **Smart** | Model-assisted annotation with SAM on detect, segment, semantic, and OBB datasets, with YOLO models on those and pose datasets, or with class-prompted models (hosted open-source or paid provider models) on detection datasets with 1–200 classes | `S`      |

Pose annotation uses `Draw` with a skeleton template; its `Smart` mode offers YOLO pose models only, with no SAM picker or auto-apply toggle. Classification uses the class sidebar directly and shows no drawing toolbar or `Smart` button at all.

Smart annotation is not currently available for [connected datasets](../integrations/index.md) backed by cloud or On Premise storage, or for datasets with more than three image channels.

The editor remembers your mode, model, and auto-apply choice for each dataset in your browser.

## Draw Mode Tools

### Bounding Box (Detect)

Draw rectangular boxes around objects:

1. Select a class in the class sidebar
2. In the default `Draw` mode, click and drag to draw a rectangle
3. Release to complete the box

![Ultralytics Platform Annotate Detect Bounding Box Drawing](https://cdn.ul.run/i/29e929eaa1d44285f9ff299f4cd245b4.avif)<!-- screenshot -->

!!! tip "Resize and Move"

    - Drag 8 corner/edge handles to resize
    - Drag the center to move
    - Press `Delete` or `Backspace` to remove selected annotation

### Polygon (Segment)

Draw precise polygon masks:

1. Select a class in the class sidebar
2. In the default `Draw` mode, click to add vertices, or hold `Shift` and move the mouse to freehand-draw dense points
3. Double-click, click the first vertex, or press `Enter` or `Escape` to close the polygon

While drawing, press `Z` to remove the last vertex, or `Delete` to discard the polygon.

![Ultralytics Platform Annotate Segment Polygon Vertices](https://cdn.ul.run/i/c10d6f45961deb17816dceb3945b6877.avif)<!-- screenshot -->

!!! tip "Edit Vertices"

    - Drag individual vertices to adjust
    - Drag the entire polygon to move
    - Click or drag an edge of the selected polygon to insert a vertex
    - Right-click a vertex and choose **Remove Point** (polygons keep at least 3 vertices), or right-click an edge and choose **Add Point**

### Keypoint (Pose)

Annotate poses using skeleton templates. Select a template from the toolbar, click once to place all keypoints, then drag individual keypoints to adjust positions.

1. Select a class in the class sidebar
2. In the default `Draw` mode, choose a skeleton template from the template picker in the toolbar
3. Click on the image to place all keypoints at once
4. Drag individual keypoints to adjust their positions

![Ultralytics Platform Annotate Pose Template Dropdown](https://cdn.ul.run/i/740678f4732fd3b862179e209a5ea8c5.avif)<!-- screenshot -->

#### Built-in Skeleton Templates

The editor includes 5 built-in templates:

| Template   | Keypoints | Description                                                                                                            |
| ---------- | --------- | ---------------------------------------------------------------------------------------------------------------------- |
| **Person** | 17        | [COCO human body pose](../../datasets/pose/coco.md) — nose, eyes, ears, shoulders, elbows, wrists, hips, knees, ankles |
| **Hand**   | 21        | [Ultralytics Hand Keypoints](../../datasets/pose/hand-keypoints.md) — wrist, thumb, index, middle, ring, pinky joints  |
| **Dog**    | 18        | AP-10K animal pose — nose, head, neck, shoulders, tailbase, tail, and 4 legs (elbows, knees, paws)                     |
| **Face**   | 68        | iBUG 300W facial landmarks — jaw, eyebrows, nose, eyes, mouth                                                          |
| **Box**    | 4         | Corner keypoints — top-left, top-right, bottom-right, bottom-left                                                      |

![Ultralytics Platform Annotate Pose Keypoints Skeleton](https://cdn.ul.run/i/e4a90c1619058fa74f045e6ba7d00b27.avif)<!-- screenshot -->

#### Custom Skeleton Templates

Create custom templates for any pose structure:

1. Open the template picker in the toolbar and choose **New Template...**
2. Optionally, click **Start from...** to load keypoints and connections from an existing template as a starting point
3. Place keypoints on the canvas by clicking
4. Name each keypoint and customize colors
5. Connect keypoints by selecting two points (connections are drawn automatically as you place sequential keypoints)
6. Save the template for reuse across your dataset

![Ultralytics Platform Annotate Pose Custom Template](https://cdn.ul.run/i/4bced0f094f4707c361de3ca93108835.avif)<!-- screenshot -->

Custom templates are saved to the dataset's workspace and available in all of its pose datasets. Edit or delete them from the template picker.

!!! tip "Template Workflow"

    The template system replaces manual sequential keypoint placement. Instead of clicking 17 times for a COCO skeleton, select the Person template and click once — all keypoints are placed in the correct skeleton layout. Then drag to adjust positions for the specific pose.

!!! info "Keypoint Visibility"

    Each keypoint has a visibility flag: `0` = not labeled, `1` = labeled but occluded, `2` = labeled and visible. Keypoints you place are labeled visible (`2`). Right-click a keypoint and choose **Hide Point** to mark it not labeled (`0`), or right-click the pose and choose **Reset Visibility** to show its hidden keypoints again. Imported labels keep their visibility flags.

### Oriented Bounding Box (OBB)

Draw rotated boxes for angled objects:

1. Select a class in the class sidebar
2. In the default `Draw` mode, click and drag to draw an initial box
3. Use the rotation handle to adjust angle
4. Drag corner handles to resize

![Ultralytics Platform Annotate Obb Rotated Box](https://cdn.ul.run/i/bfdc7cf3feb3e9000529b3ed40a9889a.avif)<!-- screenshot -->

### Classification (Classify)

Assign image-level class labels:

1. Click an image to open the fullscreen editor
2. Select a class in the class sidebar, or press a number key from `1-9`

![Ultralytics Platform Annotate Classify Side Panel](https://cdn.ul.run/i/d408f0440a059a9e2139d8aa41f85e45.avif)<!-- screenshot -->

## Smart Annotation

Smart annotation adds model-assisted annotation to the editor. In Smart mode, you can use [Segment Anything Model (SAM)](../../models/sam.md) for click-based annotation or use pretrained Ultralytics YOLO models and your own fine-tuned YOLO models to add predictions as annotations. On detection datasets with 1–200 classes, the picker also offers [class-prompted models](#class-prompted-smart-annotation) that detect the dataset's classes: six hosted open-source models, hosted text-prompted SAM 3 and SAM 3.1, and paid vision models from nine providers. SAM smart annotation is available for **detect**, **segment**, **semantic**, and **OBB** tasks; YOLO smart annotation also covers **pose**.

### SAM Smart Annotation

With a SAM model selected:

1. Select `Smart` or press `S`
2. Click on the object you want to annotate — SAM generates an initial mask in real-time
3. Refine the mask with additional clicks: click **outside** the current mask to add coverage, or click **inside** the current mask to subtract regions
4. Press `Enter` or `Escape` to save the annotation, or enable **auto-apply** for one-click workflows

![Ultralytics Platform Annotate Sam Positive Negative Points Mask](https://cdn.ul.run/i/f7687031600b3e8369f249e53568a4dd.avif)<!-- screenshot -->

```mermaid
flowchart TD
    A([Press S]) --> B[Click the object]
    B --> C[SAM generates a mask]
    C --> D{Auto-apply on?}
    D -->|no| F{Mask accurate?}
    D -->|yes| E([Mask applied])
    F -->|yes| G([Press Enter])
    F -->|no, refine| B
```

!!! tip "SAM Tips"

    - Start with a click on the object center
    - Click again outside the mask to expand coverage
    - Click inside the mask to subtract unwanted regions
    - Enable **auto-apply** (`A`) for one-click annotation
    - Hold `Shift` while auto-apply is on to place multiple points before the mask is applied
    - Works best for distinct objects with clear edges
    - Use a few refinement clicks for elongated or overlapping objects

SAM smart annotation can generate:

- **Polygons** for segmentation tasks
- **Bounding boxes** for detection tasks
- **Oriented boxes** for OBB tasks

!!! warning "SAM Task Support"

    SAM smart annotation is only available for **detect**, **segment**, **semantic**, and **OBB** tasks. Pose datasets use [YOLO smart annotation](#yolo-smart-annotation) instead, and classification requires manual annotation.

#### Auto-Apply Mode

Auto-apply mode speeds up Smart annotation by automatically saving the SAM mask after each click — no need to press `Enter`. Toggle it with the auto-apply button in the toolbar or press `A`.

| Mode                         | Behavior                                             |
| ---------------------------- | ---------------------------------------------------- |
| **Auto-apply ON**            | Mask applies automatically after each click          |
| **Auto-apply ON + `Shift`**  | Place multiple points first, mask applies on release |
| **Auto-apply OFF** (default) | Place points freely, press `Enter` to apply          |

![Ultralytics Platform Annotate Sam Auto Apply Toggle](https://cdn.ul.run/i/4d794c1ede1012d4d2399fc1dae1a495.avif)<!-- screenshot -->

!!! tip "When to Use Auto-Apply"

    Auto-apply is ideal for datasets with well-separated objects where a single click produces an accurate mask. For complex or overlapping objects, turn auto-apply off and use multiple positive/negative points to refine the mask before saving.

#### SAM Model Selection

When Smart mode is active, a model picker appears in the toolbar. Six SAM models are available — choose based on the speed vs. accuracy trade-off that suits your dataset:

| Model             | Parameters | Speed    | Notes                      |
| ----------------- | ---------- | -------- | -------------------------- |
| **SAM 2.1 Tiny**  | 0.04B      | Fastest  |                            |
| **SAM 2.1 Small** | 0.05B      | Fast     |                            |
| **SAM 2.1 Base**  | 0.08B      | Moderate |                            |
| **SAM 2.1 Large** | 0.22B      | Slower   | Most accurate of SAM 2.1   |
| **SAM 3**         | 0.86B      | Slowest  |                            |
| **SAM 3.1**       | 0.87B      | Slowest  | Default, latest generation |

![Ultralytics Platform Annotate Sam Model Selector](https://cdn.ul.run/i/28f68e5f2be0ed1599ed87ba08518191.avif)<!-- screenshot -->

Switching models while Smart mode is active re-initializes the predictor for the current image automatically.

### YOLO Smart Annotation

With a YOLO model selected, Smart annotation can add predictions from pretrained Ultralytics models or your own fine-tuned models.

1. Select `Smart` or press `S`
2. Select a YOLO model from the model picker in the toolbar (`Models` or `My Models`)
3. Click `Predict`
4. Review the added annotations and make any needed corrections

![Ultralytics Platform Annotate Smart Annotation Yolo Model](https://cdn.ul.run/i/9f69f3b2bafe56ae76e131b328692cab.avif)<!-- screenshot -->

!!! tip "YOLO Model Notes"

    - The model picker lists models that match the current dataset task, so a pose dataset offers pose models. Detect and segment datasets also show each other's models, disabled.
    - If the model's classes differ from the dataset's, a **Map classes** dialog maps each model class to a dataset class or skips it, and on a dataset without classes it creates them.
    - Duplicate predictions are skipped when they overlap an existing annotation of the same class at IoU `0.7` or higher.

### Class-Prompted Smart Annotation

On a detection dataset with 1–200 classes, select a class-prompted model and click `Predict` (or press `P`): it detects the dataset's classes across the whole image with model-specific thresholds and adds editable boxes that you review and save like YOLO predictions. These models return no confidence scores, so the prediction settings (confidence and IoU) are hidden while one is selected.

Hosted models run on Ultralytics Platform with no provider key; Moondream 3.1 is the default:

| Model                                            | Picker project     | Parameters |
| ------------------------------------------------ | ------------------ | ---------- |
| **Moondream 3.1**                                | Open-source models | 9B         |
| **Qwen3.8 27B**                                  | Open-source models | 27B        |
| [**YOLOE-26x**](../../models/yoloe.md)           | Open-source models | 0.09B      |
| **Florence-2 Large**                             | Open-source models | 0.78B      |
| **OWLv2 Large**                                  | Open-source models | 0.44B      |
| **Grounding DINO Base**                          | Open-source models | 0.23B      |
| [**SAM 3 Text**](../../models/sam-3.md)          | Meta               | 0.86B      |
| [**SAM 3.1 Text**](../../models/sam-3.md#sam-31) | Meta               | 0.87B      |

Paid vision models from OpenAI (including GPT-6 Astra and GPT-6.1 Sol), Anthropic (including Claude Fable 5.1 and Claude Opus 5.5), Google (including Gemini 4 Argon), Meta, SpaceXAI, DeepSeek, Z.ai, Kimi, and Xiaomi MiMo appear under each provider's project in the picker, by API name:

<platform-annotation-models></platform-annotation-models>

A paid provider model runs with the provider key saved in the dataset workspace's [**Settings > API Keys**](../account/api-keys.md#provider-keys-for-agents-and-annotation); without one, the prediction fails with an **Add API key** action. The provider bills your key for each prediction. After each prediction, the toast shows the number of objects detected, the elapsed time, and the cost: **Free** for a hosted model; for a paid model, the estimated provider cost when one is returned, otherwise **Billed by** and the provider name.

### Batch Annotation

Batch Annotation runs one model — a YOLO model, or on detection datasets with 1–200 classes a class-prompted model — over a whole dataset instead of the open image. Open it from the dataset page with **More actions > Batch Annotation**, or from the **Annotate all** action on the toast after an editor prediction that finds objects. It is available to dataset editors on Platform-hosted datasets with up to three image channels, for every task except depth.

1. Select a model from the picker (`Models`, including the **Open-source models** and provider projects on detection datasets with 1–200 classes, or `My Models`); on a detection dataset the dialog opens with Moondream 3.1 selected
2. For a YOLO model, adjust the confidence (default `0.25`) and IoU (default `0.7`) sliders — the sample images beside the settings show what the model finds as you move them. A class-prompted model detects the dataset classes (1–200) with model-specific thresholds instead of these settings and returns no scores
3. Turn on **Include annotated images** to also run over images that already have labels; the run adds what the model finds and keeps the labels they have
4. Review the **Estimated Cost** and click **Start**

![Ultralytics Platform Datasets Batch Annotation Dialog Sample Previews](https://cdn.ul.run/i/0d60fe240ab6e865901166baf7c6d956.avif)<!-- screenshot -->

By default only unlabeled images are annotated, and existing labels are never changed. A run needs dataset classes. For a YOLO model, if the model's classes differ from the dataset's, a **Map classes** step maps each model class to a dataset class or skips it, and on a dataset without classes it creates them — the run starts only after the classes exist. Starting a run saves a [dataset version](datasets.md#versions-tab) first, so you can restore the dataset if you don't like the result.

The dataset page shows the run's progress, and **Stop** keeps and bills the images processed so far. When the run finishes, a summary shows the images processed and the annotations and classes added.

!!! note "Batch Annotation Cost"

    Batch Annotation costs $1.00 per 1,000 processed images, with a minimum of $0.01 per run. The estimate is held from your balance when the run starts and settled for the images actually processed; the charge appears on the [Billing tab](../account/billing.md#transaction-types) as **Auto-Annotation** once you dismiss the run summary. With a paid provider model, this is the Platform processing fee only: the provider also bills your API key for the test-run previews and the annotations.

## Class Sidebar

The annotation editor includes a collapsible class sidebar on the right side of the canvas. The sidebar provides:

- **Search classes**: Filter the class list by typing in the search field. Press `Enter` on an exact match to select it, or create a new class if no match exists.
- **Create new class inline**: Click `Add class` at the bottom of the list, type a name, and optionally pick a custom color. Press `Enter` to create.
- **Edit class name inline**: Hover over a class name and click the pencil icon to rename it.
- **Color picker**: Click the color swatch next to any class to change its color.
- **Per-class annotation count**: Each class row shows a superscript count of annotations.
- **Expand/collapse**: Click the chevron to expand a class and see individual annotations listed below it.
- **Bidirectional hover highlighting**: Hovering an annotation on the canvas highlights it in the sidebar, and vice versa. The sidebar auto-scrolls to the relevant class. Hovering a class row, or its chip in the class breakdown below the image, highlights every annotation of that class.
- **Hide/show a whole class**: Click the eye icon on a class row to hide or show every annotation of that class at once.
- **Hide/show individual annotations**: Click the eye icon on any annotation row to toggle its visibility on the canvas.
- **Delete annotations**: Click the trash icon on any annotation row to delete it.
- **Keyboard shortcuts**: Press `1-9` to quickly select the first 9 classes, `H` to toggle the visibility of every annotation on the image, or `]` to show or hide the sidebar.

## Context Menu

Right-click an annotation to open a context menu with:

| Action               | Shortcut               |
| -------------------- | ---------------------- |
| Bring to Front       | `Cmd/Ctrl+Shift+]`     |
| Send to Back         | `Cmd/Ctrl+Shift+[`     |
| Bring Forward        | `Cmd/Ctrl+]`           |
| Send Backward        | `Cmd/Ctrl+[`           |
| Hide Annotation(s)   |                        |
| Delete Annotation(s) | `Delete` / `Backspace` |

Right-clicking a polygon vertex or edge adds **Remove Point** or **Add Point**, and right-clicking a pose keypoint adds **Hide Point** and **Reset Visibility**. The menu also offers [**Blur faces**](datasets.md#blur-faces) when available.

## Visibility Controls

The visibility dropdown (eye icon) lets you toggle display of individual elements:

| Toggle              | Description                                                                                                     |
| ------------------- | --------------------------------------------------------------------------------------------------------------- |
| **Annotations**     | Show or hide all annotation overlays                                                                            |
| **Class labels**    | Show or hide class name labels on annotations                                                                   |
| **Show pixels**     | Toggle pixelated rendering for zoom inspection (fullscreen)                                                     |
| **Crosshairs**      | Show crosshair cursor with pixel coordinates while annotating                                                   |
| **Nav thumbnails**  | Show navigation thumbnail strip (fullscreen)                                                                    |
| **Bottom info bar** | Show or hide the image info bar at the bottom (fullscreen)                                                      |
| **Show all**        | Toggle annotations, labels, crosshairs, thumbnails, and the bottom info bar at once (does not affect pixelated) |

## Crosshair Cursor

While annotating, a crosshair overlay tracks the cursor position and displays pixel coordinates on the canvas. This helps place annotations with precision. Toggle it via the visibility dropdown.

## SAM Hover Preview

In Smart mode, SAM provides a real-time hover preview before you click any points. This preview is available for **detect**, **segment**, **semantic**, and **OBB** tasks. Once you add refinement clicks, the preview updates to reflect the current mask and the annotation type for the active task.

## Polygon Vertex Editing

For segment and semantic annotations, you can edit polygon vertices after drawing:

- **Move vertices**: Drag any vertex handle to reposition it
- **Add vertices**: Click or drag an edge of the selected polygon, or right-click an edge and choose **Add Point**
- **Remove vertices**: Right-click a vertex and choose **Remove Point**; polygons keep at least 3 vertices

## Class Management

### Creating Classes

Define annotation classes for your dataset in the `Classes` tab:

1. Navigate to the `Classes` tab
2. Use the input field at the bottom to type a class name
3. Click `Add` or press `Enter`
4. A color is assigned automatically from the Ultralytics palette

![Ultralytics Platform Annotate Classes Tab Add New Class](https://cdn.ul.run/i/d0d213595ef0871c12dd35514ea2893f.avif)<!-- screenshot -->

### Add New Class During Annotation

You can create new classes directly while annotating without leaving the editor:

1. Draw an annotation on the image
2. In the class sidebar, click `Add class` (or type a new name in the sidebar search box)
3. Enter the class name
4. Press Enter to create and assign

This allows for a seamless workflow where you can define classes as you encounter new object types in your data.

!!! tip "Unified Classes Table"

    All classes across your dataset are managed in a unified table. Changes to class names or colors apply throughout the entire dataset automatically.

### Editing Classes

- **Rename**: Click a class name in the table to edit it inline
- **Change color**: Click the color swatch to open the color picker
- **Search**: Use the search field to filter classes by name
- **Sort**: Click column headers to sort by index, name, annotation count, or image count

### Class Colors

Each class is assigned a color from the Ultralytics palette. You can customize colors using the color picker on the `Classes` tab; the selected colors are used throughout that dataset.

## Keyboard Shortcuts

Efficient annotation with keyboard shortcuts:

=== "General"

    | Shortcut                          | Action                     |
    | --------------------------------- | -------------------------- |
    | `Cmd/Ctrl+S`                      | Save annotations           |
    | `Cmd/Ctrl+Z`                      | Undo                       |
    | `Cmd/Ctrl+Y`                      | Redo                       |
    | `Escape`                          | Save / Deselect / Exit     |
    | `Delete` / `Backspace`            | Delete selected annotation |
    | `Cmd/Ctrl+Delete`                 | Delete image               |
    | `H`                               | Toggle all annotations     |
    | `]`                               | Show or hide class sidebar |
    | `←` / `→`                         | Previous / next image      |
    | `1-9`                             | Select class 1-9           |
    | `Cmd/Ctrl+Scroll`                 | Zoom in/out                |
    | `Cmd/Ctrl++` or `Cmd/Ctrl+=`      | Zoom in                    |
    | `Cmd/Ctrl+-`                      | Zoom out                   |
    | `Cmd/Ctrl+0`                      | Reset to fit               |
    | `Space+Drag` or middle-click drag | Pan canvas                 |
    | `Shift+Click`                     | Multi-select annotations   |
    | `Cmd/Ctrl+A`                      | Select all annotations     |
    | `Cmd/Ctrl+C`                      | Copy selected annotations  |
    | `Cmd/Ctrl+X`                      | Cut selected annotations   |
    | `Cmd/Ctrl+V`                      | Paste annotations          |

=== "Modes"

    | Shortcut | Action                                          |
    | -------- | ----------------------------------------------- |
    | `V`      | Draw mode (manual, default)                     |
    | `S`      | Smart mode (SAM, YOLO, or class-prompted model) |

=== "Drawing"

    | Shortcut               | Action                                                                          |
    | ---------------------- | ------------------------------------------------------------------------------- |
    | `Click+Drag`           | Draw bounding box (detect/OBB)                                                  |
    | `Click`                | Add polygon point (segment) / Place skeleton (pose) / Place SAM point (smart)   |
    | `Shift (hold) + Move`  | Freehand draw — continuously adds polygon vertices as the mouse moves           |
    | `Click inside mask`    | Subtract region from SAM mask (negative point)                                  |
    | `Click outside mask`   | Add to SAM mask (positive point)                                                |
    | `Shift (hold) + Click` | Place multiple SAM points before auto-apply commits (Smart mode, auto-apply on) |
    | `Z`                    | Remove the last polygon vertex while drawing / last SAM point (Smart mode)      |
    | `A`                    | Toggle auto-apply (SAM Smart mode)                                              |
    | `P`                    | Run the selected YOLO or class-prompted model (Smart mode)                      |
    | `Enter`                | Complete polygon / Save SAM annotation                                          |
    | `Escape`               | Complete polygon / Save SAM annotation / Deselect / Exit                        |

=== "Arrange (Z-Order)"

    | Shortcut           | Action         |
    | ------------------ | -------------- |
    | `Cmd/Ctrl+]`       | Bring forward  |
    | `Cmd/Ctrl+[`       | Send backward  |
    | `Cmd/Ctrl+Shift+]` | Bring to front |
    | `Cmd/Ctrl+Shift+[` | Send to back   |

![Ultralytics Platform Annotate Keyboard Shortcuts Dialog](https://cdn.ul.run/i/be6c5f8c3abe5ac3d316da3feeb1926e.avif)<!-- screenshot -->

??? tip "View All Shortcuts"

    Click the keyboard icon in the annotation toolbar to open the shortcuts reference.

## Undo/Redo

The annotation editor maintains a full undo/redo history:

- **Undo**: `Cmd/Ctrl+Z`
- **Redo**: `Cmd/Ctrl+Y`

History tracks:

- Adding annotations (single and batch)
- Editing annotations (move, resize, rotate)
- Deleting annotations (single and batch)
- Changing classes (single and batch)
- Reordering annotations (z-order)
- Editing polygon vertices (add, remove, move)
- Moving keypoints

!!! info "Unlimited Undo"

    The undo stack has no fixed limit — you can undo changes made since you opened the image.

## Saving Annotations

Changes save automatically one second after the last annotation edit. They also save when you move to another image or close the fullscreen editor.

- **Save now**: Click the save button or press `Cmd/Ctrl+S`
- **Close**: Click the close button, click outside the image, or press `Escape`; closing triggers a background save for pending changes

!!! warning "Save Your Work"

    Wait for the `Saving...` or `Unsaved` status in the image information bar to clear before closing the browser tab. You can save manually at any time with the save button or `Cmd/Ctrl+S`.

## FAQ

### How accurate is SAM annotation?

SAM provides high-quality masks for most objects. Accuracy depends on:

- Object distinctiveness from background
- Image quality and resolution
- Number of positive/negative points provided

For best results, start with a click on the object center, then use outside-mask clicks to add coverage and inside-mask clicks to subtract nearby objects or background.

### Can I import existing annotations?

Yes. Upload your dataset with [YOLO-format label files](../../datasets/detect/index.md#ultralytics-yolo-format), COCO JSON annotation files, [LabelMe](../integrations/labelme.md) JSON files, or an [Ultralytics NDJSON](../../datasets/detect/index.md#ultralytics-ndjson-format) or [Labelbox](../integrations/labelbox.md) NDJSON export. Platform parses them during processing and displays them in the editor. Pascal VOC XML labels are not imported — convert them to YOLO or COCO first. See [Preparing Your Dataset](datasets.md#preparing-your-dataset).

### How do I annotate multiple objects of the same class?

After drawing an annotation:

1. Keep the same class selected
2. Draw the next annotation
3. Repeat until all objects are labeled

The keyboard shortcut `1-9` quickly selects classes.

### Can I train on partially annotated datasets?

Yes, but for best results:

- Label all objects of your target classes in each image
- Use the `Annotations` filter set to `Unannotated` to identify images that still need annotation

### Which SAM model should I use?

**SAM 3.1** is the default and the latest generation model — start there for the highest quality masks, with **SAM 3** still available. Switch to **SAM 2.1 Small** for a faster interactive workflow on common objects, or **SAM 2.1 Large** when you need higher mask precision on complex shapes. Use **SAM 2.1 Tiny** for maximum speed on simple, high-contrast objects.

### Which tasks support SAM smart annotation?

SAM smart annotation is available for **detect**, **segment**, **semantic**, and **OBB** tasks. On pose datasets, `Smart` mode runs [YOLO smart annotation](#yolo-smart-annotation) only, and classification uses manual annotation only. Smart annotation is also unavailable on connected cloud and On Premise datasets and on datasets with more than three image channels.

### Can I annotate a whole dataset at once?

Yes. Use [Batch Annotation](#batch-annotation) from **More actions > Batch Annotation** on the dataset page. It runs one model over the dataset: an official YOLO model, one of your own trained or uploaded models from `My Models`, or, on detection datasets with 1–200 classes, a class-prompted model such as SAM 3.1 Text that detects your class names. By default it annotates only unlabeled images, existing labels are kept, and a dataset version is saved first so you can restore it. It costs $1.00 per 1,000 images processed (minimum $0.01), and paid provider models are also billed by the provider. Batch Annotation works on Platform-hosted datasets with up to three image channels and is not available for depth.

### Can I auto-annotate images with GPT, Claude, or Gemini models?

Yes. On detection datasets with 1–200 classes, Smart annotation and [Batch Annotation](#batch-annotation) can run paid vision models such as Gemini 4 Argon, GPT-6.1 Sol, GPT-6 Astra, Claude Opus 5.5, and Claude Fable 5.1 with your own provider key from [**Settings > API Keys**](../account/api-keys.md#provider-keys-for-agents-and-annotation). Select the model under its provider in the model picker and click `Predict`; the provider bills your key for each prediction. The [class-prompted models](#class-prompted-smart-annotation) section lists every current model.

### Which class-prompted model should I use?

In an October 2026 Ultralytics Platform benchmark of every class-prompted model on 108 images from 36 detection datasets spanning medical, aerial, industrial, retail, and everyday scenes, Gemini 4 Argon (`gemini-4-argon`) was the most accurate, ahead of GPT-6.1 Sol, Gemini 3.8 Flash, Claude Opus 5.5, and GPT-6 Astra. Claude Haiku 5.5 (`claude-haiku-5-5`) and Gemini 3.5 Flash-Lite (`gemini-3.5-flash-lite`) were the most accurate low-cost models, and Qwen3.8 27B was the most accurate hosted model, with no provider key needed. Accuracy depends heavily on the domain: models that find nearly every object in everyday photos miss many objects in PCB, X-ray, retail, and traffic images and in some medical datasets, so run a few predictions on your own images before starting [Batch Annotation](#batch-annotation).

### Can I create custom skeleton templates for pose annotation?

Yes. Open the skeleton template picker and choose **New Template...** to open the template editor. Place keypoints, name them, draw connections, and save. Custom templates are stored in the dataset's workspace and available across all of its pose datasets.

### How do I switch between skeleton templates?

Click the template picker dropdown in the annotation toolbar. Select any built-in template (Person, Hand, Dog, Face, Box) or your saved custom templates. The selected template determines which keypoints are placed when you click on the image.

### Can I copy annotations between images?

Yes. Select one or more annotations, press `Cmd/Ctrl+C` to copy (or `Cmd/Ctrl+X` to cut), navigate to another image with the arrow keys or thumbnail strip, and press `Cmd/Ctrl+V` to paste. The clipboard persists while the fullscreen editor stays open.
